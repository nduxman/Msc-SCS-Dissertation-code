from experta import Fact, Rule, KnowledgeEngine

class SymptomSet(Fact):
    """Captured symptoms during reassessment."""
    pass

class DiagnosisEngine(KnowledgeEngine):
    def __init__(self):
        super().__init__()
        self.suggestion = "✅ No diagnosis needed."
        self.reasons = []
        self.label = None

    # Cerebral Palsy
    @Rule(SymptomSet(muscle_stiffness=True, poor_head_control=True, poor_motor_coordination=True))
    def cerebral_palsy(self):
        self.label = "Cerebral Palsy"
        self.reasons.append("Motor delays and control issues")
        self.suggestion = "🛑 Likely Cerebral Palsy. Refer to pediatric neurologist."

    # Autism Spectrum Disorder
    @Rule(SymptomSet(lack_of_social_smile=True, repetitive_behaviors=True, echolalia=True, sensory_issues=True))
    def autism(self):
        self.label = "Autism Spectrum Disorder"
        self.reasons.append("Social, behavioral, sensory and speech cues")
        self.suggestion = "🛑 Possible Autism. Recommend pediatric psychological assessment."

    # ADHD
    @Rule(SymptomSet(hyperactivity=True, inattention=True, impulsiveness=True, trouble_following_instructions=True))
    def adhd(self):
        self.label = "Attention Deficit Hyperactivity Disorder (ADHD)"
        self.reasons.append("Inattention, hyperactivity and impulsivity")
        self.suggestion = "⚠️ Suspected ADHD. Suggest behavioral evaluation."

    # Global Developmental Delay
    @Rule(SymptomSet(speech_delay=True, learning_difficulty=True, poor_memory=True, delayed_milestones=True))
    def developmental_delay(self):
        self.label = "Global Developmental Delay"
        self.reasons.append("Learning, memory and milestone delays")
        self.suggestion = "⚠️ Developmental delay. Suggest therapy and school readiness review."

    # Down Syndrome
    @Rule(SymptomSet(poor_eye_tracking=True, muscle_stiffness=True, abnormal_reflexes=True, low_tone=True))
    def down_syndrome(self):
        self.label = "Down Syndrome"
        self.reasons.append("Visual, muscle tone and reflex anomalies")
        self.suggestion = "🛑 Likely Down Syndrome. Refer for genetic testing."

    # Aggression and Self Harm - Behavioral Red Flag
    @Rule(SymptomSet(aggression=True, self_harm_behaviors=True))
    def behavioral_red_flag(self):
        self.label = "Severe Behavioral Concern"
        self.reasons.append("Aggressive and self-harming behaviors")
        self.suggestion = "🚨 Immediate referral to child psychiatrist."

    # Social Anxiety
    @Rule(SymptomSet(social_anxiety=True, lack_of_social_smile=True))
    def social_anxiety_disorder(self):
        self.label = "Possible Social Anxiety Disorder"
        self.reasons.append("Avoidance of social interaction cues")
        self.suggestion = "⚠️ Assess for anxiety and offer support mechanisms."

    # No significant symptoms
    @Rule(SymptomSet(
        poor_eye_tracking=False,
        delayed_milestones=False,
        muscle_stiffness=False,
        seizure_episodes=False,
        abnormal_reflexes=False,
        poor_head_control=False,
        lack_of_social_smile=False,
        hyperactivity=False,
        impulsiveness=False,
        speech_delay=False,
        repetitive_behaviors=False,
        learning_difficulty=False,
        poor_memory=False,
        sensory_issues=False,
        trouble_following_instructions=False,
        aggression=False,
        self_harm_behaviors=False,
        social_anxiety=False,
        echolalia=False,
        low_tone=False,
        poor_motor_coordination=False
    ))
    def no_symptoms(self):
        self.suggestion = "✅ No critical findings. Monitor and reassess after 3 months."
        self.label = None
