import json
from collections import Counter
from datetime import date

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework import generics, permissions, viewsets

from .diagnosis_engine import DiagnosisEngine, SymptomSet
from .models import Role, Clinician, Patient, RiskIndicator, RiskEvaluation, DiagnosisRecord
from .risk_engine import RiskAssessmentEngine, PatientRisk
from .serializers import ClinicianTokenSerializer, RoleSerializer, ClinicianRegistrationSerializer, \
    ClinicianListSerializer, PatientSerializer, RiskIndicatorSerializer, DiagnosisRecordSerializer


class ClinicianTokenView(TokenObtainPairView):
    serializer_class = ClinicianTokenSerializer



class RoleListAPIView(generics.ListAPIView):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    permission_classes = [permissions.AllowAny]

class ClinicianRegisterAPIView(generics.CreateAPIView):
    serializer_class = ClinicianRegistrationSerializer
    permission_classes = [permissions.AllowAny]

class RoleListCreateAPIView(generics.ListCreateAPIView):  # ✅ not ListAPIView
    queryset = Role.objects.all()
    serializer_class = RoleSerializer
    permission_classes = [permissions.AllowAny]

class ClinicianListCreateView(generics.ListCreateAPIView):
    queryset = Clinician.objects.all()
    permission_classes = [permissions.IsAdminUser]
    serializer_class = ClinicianListSerializer

class ClinicianDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Clinician.objects.all()
    serializer_class = ClinicianRegistrationSerializer
    permission_classes = [permissions.IsAdminUser]

    def put(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)

    def patch(self, request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)

class PatientListCreateView(generics.ListCreateAPIView):
    queryset = Patient.objects.all().order_by("-created_at")
    serializer_class = PatientSerializer
    permission_classes = [permissions.IsAuthenticated]


class PatientDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Patient.objects.all()
    serializer_class = PatientSerializer
    permission_classes = [permissions.IsAuthenticated]


from rest_framework import serializers, viewsets
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Patient, RiskIndicator, RiskEvaluation
from .serializers import RiskIndicatorSerializer, PatientSerializer
import json


from rest_framework import viewsets, serializers, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Patient, RiskIndicator
from .serializers import RiskIndicatorSerializer

class RiskIndicatorViewSet(viewsets.ModelViewSet):
    queryset = RiskIndicator.objects.all()
    serializer_class = RiskIndicatorSerializer

    def perform_create(self, serializer):
        data = self._compute_indicators(self.request.data.copy())
        patient_id = data.pop("patient", None)

        if not patient_id:
            raise serializers.ValidationError({"patient": "Patient ID is required."})

        try:
            patient_instance = Patient.objects.get(id=patient_id)
        except Patient.DoesNotExist:
            raise serializers.ValidationError({"patient": "Patient not found."})

        # Remove patient-only fields
        patient_only_fields = [
            "apgar_score", "birth_weight", "gestation_age",
            "head_circumference", "labour_duration", "delivery_type",
            "prematurity", "jaundice", "seizures", "admitted_nicu",
            "feeding_difficulties", "muscle_tone"
        ]
        for field in patient_only_fields:
            data.pop(field, None)

        serializer.save(patient=patient_instance, **data)

    def perform_update(self, serializer):
        self.perform_create(serializer)

    def _compute_indicators(self, data):
        try:
            apgar = float(data.get("apgar_score", 10))
            weight = float(data.get("birth_weight", 3.0))
            gestation = int(data.get("gestation_age", 40))
            head = float(data.get("head_circumference", 34))
            labour = float(data.get("labour_duration", 0))

            data["low_apgar_score"] = apgar < 7
            data["low_birth_weight"] = weight < 2.5
            data["head_circumference_abnormal"] = head < 33 or head > 37
            data["prolonged_labour"] = labour < 5 or labour > 18
            data["prematurity"] = gestation < 38
            data["admission_to_nicu"] = data.get("admitted_nicu", "").strip().lower() == "yes"
            data["muscle_tone_abnormal"] = data.get("muscle_tone", "").strip().lower() == "low"
            data["exposure_to_drugs"] = data.get("exposure_to_drugs", "").strip().lower() == "yes"

        except Exception as e:
            print(f"⚠️ Auto-computation failed: {e}")

        yes_no_fields = [
            "prolonged_labour", "prematurity", "delayed_crying", "infection_at_birth",
            "muscle_tone_abnormal", "exposure_to_drugs", "low_apgar_score", "low_birth_weight",
            "head_circumference_abnormal", "admission_to_nicu"
        ]

        for field in yes_no_fields:
            val = data.get(field)
            if field in data and isinstance(data[field], bool):
                continue  # already correctly set
            val = data.get(field)
            if isinstance(val, str):
                data[field] = val.strip().lower() == "yes"
            else:
                data[field] = False

        return data

    # ✅ Add a custom route to get by patient_id
    @action(detail=False, methods=['get'], url_path='by-patient/(?P<patient_id>[^/.]+)')
    def by_patient(self, request, patient_id=None):
        try:
            indicator = RiskIndicator.objects.get(patient_id=patient_id)
            serializer = self.get_serializer(indicator)
            return Response(serializer.data)
        except RiskIndicator.DoesNotExist:
            return Response({"detail": "No RiskIndicator matches the given patient."}, status=404)

@api_view(['POST'])
def evaluate_risk(request, patient_id):
    try:
        indicator = RiskIndicator.objects.get(patient_id=patient_id)
        patient = indicator.patient

        birth_weight = float(patient.birth_weight or 0)
        gestation_age = int(patient.gestation_age or 0)
        head_circumference = float(patient.head_circumference or 0)
        labour_duration = float(patient.labour_duration or 0)

        # Manual logic
        low_birth_weight = birth_weight < 2.5
        prolonged_labour = labour_duration < 5 or labour_duration > 18
        head_circumference_abnormal = head_circumference < 33 or head_circumference > 37
        muscle_tone_abnormal = patient.muscle_tone and patient.muscle_tone.lower() == "low"
        jaundice = str(patient.jaundice).strip().lower() == "yes"
        seizures = str(patient.seizures).strip().lower() == "yes"
        apgar_score = float(patient.apgar_score or 10)
        low_apgar_score = apgar_score < 7

        data = {
            "low_birth_weight": low_birth_weight,
            "prolonged_labour": prolonged_labour,
            "low_apgar_score": low_apgar_score,
            "delayed_crying": indicator.delayed_crying,
            "infection_at_birth": indicator.infection_at_birth,
            "muscle_tone_abnormal": muscle_tone_abnormal,
            "head_circumference_abnormal": head_circumference_abnormal,
            "admission_to_nicu": indicator.admission_to_nicu,
            "exposure_to_drugs": indicator.exposure_to_drugs,
            "jaundice": jaundice,
            "seizures": seizures,
        }

        engine = RiskAssessmentEngine()
        engine.reset()
        engine.declare(PatientRisk(**data))
        engine.run()

        is_at_risk = "AT RISK" in engine.recommendation.upper()

        RiskEvaluation.objects.create(
            patient=indicator.patient,
            triggered_indicators=json.dumps(engine.risks_triggered),
            recommendation=engine.recommendation,
            is_at_risk=is_at_risk
        )

        return Response({
            "recommendation": engine.recommendation,
            "triggered_indicators": engine.risks_triggered,
            "patient_name": patient.full_name,
            "birth_weight": birth_weight,
            "gestation_age": gestation_age,
            "apgar_score": patient.apgar_score,
            "labour_duration": labour_duration,
            "head_circumference": head_circumference,
        })

    except RiskIndicator.DoesNotExist:
        return Response({"error": "No risk indicators found."}, status=404)



@api_view(['GET'])
def patients_with_risk(request):
    patients = Patient.objects.filter(risk_indicators__isnull=False)
    serialized = PatientSerializer(patients, many=True)
    return Response(serialized.data)


from collections import Counter, defaultdict
from rest_framework.decorators import api_view, renderer_classes, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.renderers import JSONRenderer
from .models import Patient, RiskIndicator

@api_view(["GET"])
@renderer_classes([JSONRenderer])
@permission_classes([AllowAny])
def risk_analysis_summary(request):
    patients = Patient.objects.all()
    total = patients.count()

    at_risk = []
    no_risk = []
    indicators_count = Counter()
    indicator_patients = defaultdict(list)

    for p in patients:
        if hasattr(p, "risk_indicators"):
            indicators = p.risk_indicators
            triggered = []

            for field in RiskIndicator._meta.fields:
                name = field.name
                if name not in ['id', 'patient', 'created_at', 'other_notes']:
                    if getattr(indicators, name):
                        label = name.replace("_", " ").title()
                        triggered.append(label)
                        indicators_count[label] += 1
                        indicator_patients[label].append(p.full_name)

            if triggered:
                at_risk.append(p.full_name)
            else:
                no_risk.append(p.full_name)

    # ✅ Return structured JSON response only
    return Response({
        "total": total,
        "at_risk": len(at_risk),
        "no_risk": len(no_risk),
        "at_risk_patients": at_risk,
        "no_risk_patients": no_risk,
        "common_indicators": indicators_count,
        "indicator_patients": indicator_patients
    })

@api_view(['GET'])
def patients_needing_review(request):
    evaluations = RiskEvaluation.objects.filter(is_at_risk=True, scheduled_review_date__isnull=True).select_related('patient')
    data = [{
        "id": e.id,  # ADD THIS
        "patient_id": e.patient.id,
        "patient_name": e.patient.full_name,
        "recommendation": e.recommendation,
        "evaluation_date": e.evaluation_date,
        "triggered_indicators": json.loads(e.triggered_indicators),
    } for e in evaluations]
    return Response(data)


@api_view(['GET'])
def scheduled_reviews(request):
    evaluations = RiskEvaluation.objects.filter(scheduled_review_date__isnull=False).select_related('patient')
    data = [{
        "id": e.id,
        "patient_id": e.patient.id,
        "patient_name": e.patient.full_name,
        "recommendation": e.recommendation,
        "evaluation_date": e.evaluation_date,
        "scheduled_review_date": e.scheduled_review_date,
        "triggered_indicators": json.loads(e.triggered_indicators),
    } for e in evaluations]
    return Response(data)



@api_view(['PATCH'])
def set_review_date(request, eval_id):
    try:
        evaluation = RiskEvaluation.objects.get(id=eval_id)
        review_date = request.data.get("scheduled_review_date")

        if not review_date:
            return Response({"error": "Review date is required."}, status=400)

        evaluation.scheduled_review_date = review_date
        evaluation.save()

        return Response({"message": "✅ Review date set successfully."})
    except RiskEvaluation.DoesNotExist:
        return Response({"error": "Evaluation not found."}, status=404)

# ✅ Updated generate_diagnosis view with mapping to match Experta rules
def map_symptoms_to_engine_keys(raw_symptoms):
    mapping = {
        # Existing keys
        "poor_eye_tracking": "poor_eye_tracking",
        "delayed_milestones": "delayed_milestones",
        "muscle_stiffness": "muscle_stiffness",
        "seizure_episodes": "seizure_episodes",
        "abnormal_reflexes": "abnormal_reflexes",
        "poor_head_control": "poor_head_control",
        "lack_of_social_smile": "lack_of_social_smile",
        "inattentiveness": "inattention",           # ✅ mapped to correct rule
        "impulsivity": "impulsiveness",             # ✅ mapped
        "hyperactivity": "hyperactivity",
        "speech_delay": "speech_delay",
        "repetitive_behaviors": "repetitive_behaviors",
        "poor_social_interaction": "social_anxiety",  # ✅ intentional redirect
        "low_muscle_tone": "low_tone",
        "flat_facial_profile": "flat_facial_profile",

        # 🔁 New keys to match updated engine
        "echolalia": "echolalia",
        "sensory_issues": "sensory_issues",
        "trouble_following_instructions": "trouble_following_instructions",
        "learning_difficulty": "learning_difficulty",
        "poor_memory": "poor_memory",
        "aggression": "aggression",
        "self_harm_behaviors": "self_harm_behaviors",
        "poor_motor_coordination": "poor_motor_coordination",
    }

    result = {}
    for frontend_key, backend_key in mapping.items():
        result[backend_key] = raw_symptoms.get(frontend_key, False)
    return result



@api_view(['POST'])
def generate_diagnosis(request, patient_id):
    symptoms = map_symptoms_to_engine_keys(request.data)

    engine = DiagnosisEngine()
    engine.reset()
    engine.declare(SymptomSet(**symptoms))
    engine.run()

    # Save to DB (concatenated for history)
    record = DiagnosisRecord.objects.create(
        patient_id=patient_id,
        symptoms=", ".join([k for k, v in request.data.items() if v]),
        suggestion=" | ".join(engine.suggestions),
        diagnosis_label=" | ".join(filter(None, engine.labels))
    )

    return Response({
        "suggestions": engine.suggestions,
        "reasons": engine.reasons,
        "record_id": record.id,
        "labels": engine.labels,
        "triggered_symptoms": engine.triggered_symptoms
    })


@api_view(["GET"])
def diagnosis_history(request, patient_id):
    label = request.GET.get("label")
    records = DiagnosisRecord.objects.filter(patient_id=patient_id).order_by("-created_at")

    if label:
        records = records.filter(diagnosis_label__icontains=label)

    serializer = DiagnosisRecordSerializer(records, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def dashboard_overview(request):
    stats = get_dashboard_stats()
    activity = get_recent_activities()
    return Response({
        "stats": stats,
        "activity": activity
    })

def get_dashboard_stats():
    return {
        "clinicians": Clinician.objects.count(),
        "high_risk": RiskEvaluation.objects.filter(is_at_risk=True).values("patient_id").distinct().count(),
        "scheduled": RiskEvaluation.objects.filter(scheduled_review_date__isnull=False).count(),
        "diagnoses": DiagnosisRecord.objects.count(),
    }

def get_recent_activities(limit=10):
    activities = []

    latest_eval = RiskEvaluation.objects.select_related("patient").order_by("-evaluation_date").first()
    if latest_eval:
        activities.append(f"🧠 Risk analysis run for {latest_eval.patient.full_name}")

    latest_diag = DiagnosisRecord.objects.select_related("patient").order_by("-created_at").first()
    if latest_diag:
        activities.append(f"🩺 Diagnosis suggestion generated for {latest_diag.patient.full_name}")

    today_reviews = RiskEvaluation.objects.filter(scheduled_review_date=date.today()).count()
    if today_reviews:
        activities.append(f"📆 {today_reviews} reviews scheduled for today")

    flagged_today = RiskEvaluation.objects.filter(evaluation_date__date=date.today(), is_at_risk=True).count()
    if flagged_today:
        activities.append(f"⚠️ {flagged_today} patients flagged as high risk")

    return activities[:limit]
