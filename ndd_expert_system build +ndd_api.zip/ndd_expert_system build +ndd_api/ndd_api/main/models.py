from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager, Permission
from django.db import models

class Role(models.Model):
    """Role Model - Links clinicians to permission sets."""
    name = models.CharField(max_length=50, unique=True)
    permissions = models.ManyToManyField(Permission, blank=True)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

class ClinicianManager(BaseUserManager):
    def create_user(self, email, name, password=None, **extra_fields):
        if not email:
            raise ValueError("The Email field is required")
        email = self.normalize_email(email)
        user = self.model(email=email, name=name, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, name, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        return self.create_user(email, name, password, **extra_fields)

class Clinician(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=15, blank=True, null=True)
    id_number = models.CharField(max_length=50, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    region = models.CharField(max_length=100, blank=True, null=True)
    education_level = models.CharField(max_length=255, blank=True, null=True)
    qualification = models.CharField(max_length=255, blank=True, null=True)  # e.g., Doctor, Nurse
    role = models.ForeignKey(Role, on_delete=models.SET_NULL, null=True, blank=True)

    registration_date = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name']

    objects = ClinicianManager()

    def __str__(self):
        return f"{self.name} - {self.qualification or 'Clinician'}"


class Patient(models.Model):
    SEX_CHOICES = [("Male", "Male"), ("Female", "Female")]
    YES_NO = [("Yes", "Yes"), ("No", "No")]
    TONE_CHOICES = [("Normal", "Normal"), ("Low", "Low"), ("High", "High")]

    full_name = models.CharField(max_length=255)
    dob = models.DateField()
    sex = models.CharField(max_length=10, choices=SEX_CHOICES)
    mother_name = models.CharField(max_length=255, blank=True, null=True)
    contact_number = models.CharField(max_length=20, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)

    # Birth & Risk Data
    birth_weight = models.DecimalField(max_digits=4, decimal_places=2, blank=True, null=True)
    apgar_score = models.CharField(max_length=10, blank=True, null=True)
    prematurity = models.CharField(max_length=5, choices=YES_NO, blank=True, null=True)
    gestation_age = models.PositiveIntegerField(blank=True, null=True)
    delivery_type = models.CharField(max_length=20, blank=True, null=True)
    labour_duration = models.DecimalField(max_digits=4, decimal_places=1, blank=True, null=True)
    jaundice = models.CharField(max_length=5, choices=YES_NO, blank=True, null=True)
    seizures = models.CharField(max_length=5, choices=YES_NO, blank=True, null=True)
    head_circumference = models.DecimalField(max_digits=4, decimal_places=1, blank=True, null=True)
    admitted_nicu = models.CharField(max_length=5, choices=YES_NO, blank=True, null=True)
    feeding_difficulties = models.CharField(max_length=5, choices=YES_NO, blank=True, null=True)
    muscle_tone = models.CharField(max_length=10, choices=TONE_CHOICES, blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.full_name} ({self.dob})"


class RiskIndicator(models.Model):
    patient = models.OneToOneField('Patient', on_delete=models.CASCADE, related_name='risk_indicators')

    low_birth_weight = models.BooleanField(default=False)
    prolonged_labour = models.BooleanField(default=False)
    assisted_delivery = models.BooleanField(default=False)
    low_apgar_score = models.BooleanField(default=False)
    delayed_crying = models.BooleanField(default=False)
    neonatal_convulsions = models.BooleanField(default=False)
    infection_at_birth = models.BooleanField(default=False)
    feeding_issues = models.BooleanField(default=False)
    muscle_tone_abnormal = models.BooleanField(default=False)
    head_circumference_abnormal = models.BooleanField(default=False)
    admission_to_nicu = models.BooleanField(default=False)
    exposure_to_drugs = models.BooleanField(default=False)
    other_notes = models.TextField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)


class RiskEvaluation(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    triggered_indicators = models.TextField()  # Store as JSON or comma-separated string
    recommendation = models.TextField()
    is_at_risk = models.BooleanField()
    evaluation_date = models.DateTimeField(auto_now_add=True)
    scheduled_review_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"{self.patient.full_name} - {'At Risk' if self.is_at_risk else 'No Risk'}"


class DiagnosisRecord(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    symptoms = models.TextField()
    suggestion = models.TextField()
    diagnosis_label = models.CharField(max_length=100, blank=True, null=True)  # ✅ New Field
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Diagnosis for {self.patient.full_name} - {self.created_at.date()}"



