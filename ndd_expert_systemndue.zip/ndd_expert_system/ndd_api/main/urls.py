from django.urls import path, include
from rest_framework.routers import DefaultRouter

from main import views
from main.views import ClinicianTokenView, RoleListAPIView, ClinicianRegisterAPIView, RoleListCreateAPIView, \
    ClinicianListCreateView, ClinicianDetailView, PatientListCreateView, RiskIndicatorViewSet, evaluate_risk, \
    risk_analysis_summary, patients_needing_review, set_review_date, scheduled_reviews, generate_diagnosis, \
    diagnosis_history, PatientDetailView

router = DefaultRouter()
router.register(r"risk-indicators", RiskIndicatorViewSet)
urlpatterns = [
    path('', include(router.urls)),
    path('token/', ClinicianTokenView.as_view(), name='token_obtain_pair'),
    path('roles/', RoleListCreateAPIView.as_view(), name='roles'),  # ✅ Correct
    path('clinicians/register/', ClinicianRegisterAPIView.as_view(), name='clinician-register'),
    path('clinicians/', ClinicianListCreateView.as_view(), name='clinician-list'),
    path('clinicians/<int:pk>/', ClinicianDetailView.as_view(), name='clinician-detail'),
    path('patients/', PatientListCreateView.as_view(), name='patients'),
    path('patients/<int:pk>/', PatientDetailView.as_view(), name='patient-detail'),
    path("evaluate-risk/", evaluate_risk, name="evaluate-risk"),
    path('patients/with-risk/', views.patients_with_risk, name='patients-with-risk'),
    path('evaluate-risk/<int:patient_id>/', views.evaluate_risk, name='evaluate-risk'),
    path("risk-summary/", risk_analysis_summary),
    path("patients-needing-review/", patients_needing_review),
    path("set-review-date/<int:eval_id>/", set_review_date),
    path("scheduled-reviews/", scheduled_reviews),
    path("generate-diagnosis/<int:patient_id>/", generate_diagnosis, name="generate-diagnosis"),
    path("diagnosis-history/<int:patient_id>/", diagnosis_history),
    path('dashboard-overview/', views.dashboard_overview, name='dashboard-overview'),
]
