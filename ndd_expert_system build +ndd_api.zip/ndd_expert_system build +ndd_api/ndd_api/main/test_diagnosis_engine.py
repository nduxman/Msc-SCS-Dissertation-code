import unittest
from diagnosis_engine import DiagnosisEngine, SymptomSet

class TestDiagnosisEngine(unittest.TestCase):

    def run_engine_with_symptoms(self, **kwargs):
        engine = DiagnosisEngine()
        engine.reset()
        engine.declare(SymptomSet(**kwargs))
        engine.run()
        return engine

    def test_down_syndrome(self):
        engine = self.run_engine_with_symptoms(
            poor_eye_tracking=True,
            muscle_stiffness=True,
            abnormal_reflexes=True,
            low_tone=True
        )
        self.assertIn("Down Syndrome", engine.labels)
        self.assertIn("poor_eye_tracking", engine.triggered_symptoms)
        self.assertIn("low_tone", engine.triggered_symptoms)

    def test_autism(self):
        engine = self.run_engine_with_symptoms(
            lack_of_social_smile=True,
            repetitive_behaviors=True,
            echolalia=True,
            sensory_issues=True
        )
        self.assertIn("Autism Spectrum Disorder", engine.labels)
        self.assertIn("echolalia", engine.triggered_symptoms)

    def test_adhd(self):
        engine = self.run_engine_with_symptoms(
            hyperactivity=True,
            inattention=True,
            impulsiveness=True,
            trouble_following_instructions=True
        )
        self.assertIn("Attention Deficit Hyperactivity Disorder (ADHD)", engine.labels)
        self.assertIn("hyperactivity", engine.triggered_symptoms)

    def test_partial_speech_delay(self):
        engine = self.run_engine_with_symptoms(speech_delay=True)
        self.assertIn("Possible Language Delay", engine.labels)
        self.assertIn("speech_delay", engine.triggered_symptoms)

    def test_no_symptoms(self):
        engine = self.run_engine_with_symptoms(
            poor_eye_tracking=False,
            delayed_milestones=False,
            muscle_stiffness=False,
            seizure_episodes=False,
            abnormal_reflexes=False,
            poor_head_control=False,
            lack_of_social_smile=False,
            hyperactivity=False,
            impulsiveness=False,
            speech_delay=False,
            repetitive_behaviors=False,
            learning_difficulty=False,
            poor_memory=False,
            sensory_issues=False,
            trouble_following_instructions=False,
            aggression=False,
            self_harm_behaviors=False,
            social_anxiety=False,
            echolalia=False,
            low_tone=False,
            poor_motor_coordination=False,
            flat_facial_profile=False,
            inattention=False
        )
        self.assertIn("✅ No critical findings. Monitor and reassess after 3 months.", engine.suggestions)
        self.assertEqual(engine.triggered_symptoms, [])

if __name__ == '__main__':
    unittest.main()
