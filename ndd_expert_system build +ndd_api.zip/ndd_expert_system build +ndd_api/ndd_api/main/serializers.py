from django.contrib.auth.models import Permission
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from main.models import Clinician, Role, Patient, RiskIndicator, RiskEvaluation, DiagnosisRecord


class ClinicianTokenSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['name'] = user.name
        token['email'] = user.email
        return token


# 🔹 Serializer for Permission objects
class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permission
        fields = ['id', 'codename', 'name']

# 🔹 Main Role serializer
class RoleSerializer(serializers.ModelSerializer):
    permissions = PermissionSerializer(many=True, read_only=True)

    class Meta:
        model = Role
        fields = ['id', 'name', 'description', 'permissions']


class ClinicianRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=False)
    role = serializers.PrimaryKeyRelatedField(queryset=Role.objects.all(), required=False)

    class Meta:
        model = Clinician
        fields = [
            'id', 'email', 'name', 'password', 'phone', 'id_number', 'address',
            'city', 'region', 'education_level', 'qualification', 'role'
        ]

    def create(self, validated_data):
        password = validated_data.pop('password')
        clinician = Clinician.objects.create_user(password=password, **validated_data)
        return clinician

    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        if password:
            instance.set_password(password)

        instance.save()
        return instance


class RoleMiniSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ['id', 'name']

class ClinicianListSerializer(serializers.ModelSerializer):
    role = RoleMiniSerializer(read_only=True)

    class Meta:
        model = Clinician
        fields = ['id', 'name', 'email', 'phone', 'role']


class PatientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Patient
        fields = '__all__'


# Option 1: Extend serializer for RiskIndicator
class RiskIndicatorSerializer(serializers.ModelSerializer):
    apgar_score = serializers.CharField(source='patient.apgar_score', read_only=True)
    birth_weight = serializers.DecimalField(source='patient.birth_weight', read_only=True, max_digits=4, decimal_places=2)
    gestation_age = serializers.IntegerField(source='patient.gestation_age', read_only=True)

    class Meta:
        model = RiskIndicator
        fields = '__all__'



class RiskEvaluationSerializer(serializers.ModelSerializer):
    class Meta:
        model = RiskEvaluation
        fields = '__all__'


# serializers.py (update serializer)
class DiagnosisRecordSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source="patient.full_name", read_only=True)

    class Meta:
        model = DiagnosisRecord
        fields = ["id", "patient", "patient_name", "symptoms", "suggestion", "diagnosis_label", "created_at"]

