from experta import Fact, Rule, KnowledgeEngine

class PatientRisk(Fact):
    """Fact for patient's risk indicators"""
    pass

class RiskAssessmentEngine(KnowledgeEngine):
    def __init__(self):
        super().__init__()
        self.recommendation = "✅ No risk indicators found."
        self.risks_triggered = []

    @Rule(PatientRisk(low_birth_weight=True))
    def low_birth_weight_risk(self):
        self.risks_triggered.append("Low birth weight")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(prolonged_labour=True))
    def prolonged_labour_risk(self):
        self.risks_triggered.append("Prolonged labour")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(assisted_delivery=True))
    def assisted_delivery_risk(self):
        self.risks_triggered.append("Assisted delivery")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(low_apgar_score=True))
    def low_apgar_risk(self):
        self.risks_triggered.append("Low APGAR score")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(delayed_crying=True))
    def delayed_crying_risk(self):
        self.risks_triggered.append("Delayed crying")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(neonatal_convulsions=True))
    def neonatal_convulsions_risk(self):
        self.risks_triggered.append("Neonatal convulsions")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(infection_at_birth=True))
    def infection_at_birth_risk(self):
        self.risks_triggered.append("Infection at birth")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(feeding_issues=True))
    def feeding_issues_risk(self):
        self.risks_triggered.append("Feeding issues")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(muscle_tone_abnormal=True))
    def muscle_tone_abnormal_risk(self):
        self.risks_triggered.append("Abnormal muscle tone")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(head_circumference_abnormal=True))
    def head_circumference_abnormal_risk(self):
        self.risks_triggered.append("Abnormal head circumference")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(admission_to_nicu=True))
    def admission_to_nicu_risk(self):
        self.risks_triggered.append("Admitted to NICU")
        self.declare(Fact(risk=True))

    @Rule(PatientRisk(exposure_to_drugs=True))
    def exposure_to_drugs_risk(self):
        self.risks_triggered.append("Exposure to drugs")
        self.declare(Fact(risk=True))

    @Rule(Fact(risk=True))
    def confirm_risk(self):
        self.recommendation = "🛑 Patient is AT RISK. Recommend clinical review."

    @Rule(
        PatientRisk(
            low_birth_weight=False,
            prolonged_labour=False,
            assisted_delivery=False,
            low_apgar_score=False,
            delayed_crying=False,
            neonatal_convulsions=False,
            infection_at_birth=False,
            feeding_issues=False,
            muscle_tone_abnormal=False,
            head_circumference_abnormal=False,
            admission_to_nicu=False,
            exposure_to_drugs=False,
        )
    )
    def no_risk_detected(self):
        self.recommendation = "✅ No risk indicators found."
