from experta import Fact, Rule, KnowledgeEngine

class SymptomSet(Fact):
    """Captured symptoms during reassessment."""
    pass

class DiagnosisEngine(KnowledgeEngine):
    def __init__(self):
        super().__init__()
        self.suggestions = []
        self.reasons = []
        self.labels = []
        self.triggered_symptoms = []

    def declare(self, *facts):
        for fact in facts:
            for k, v in fact.items():
                if v:
                    self.triggered_symptoms.append(k)
        return super().declare(*facts)

    # --- DIFFERENTIAL DIAGNOSIS LOGIC ---

    # CP vs Down Syndrome
    @Rule(SymptomSet())
    def differential_cerebral_vs_downs(self):
        cp_symptoms = {
            'muscle_stiffness', 'poor_head_control', 'abnormal_reflexes', 'poor_motor_coordination', 'delayed_milestones'
        }
        downs_symptoms = {
            'low_tone', 'poor_eye_tracking', 'abnormal_reflexes', 'flat_facial_profile', 'speech_delay'
        }
        cp_count = len(cp_symptoms & set(self.triggered_symptoms))
        downs_count = len(downs_symptoms & set(self.triggered_symptoms))

        cp_exclusive = cp_symptoms - downs_symptoms
        downs_exclusive = downs_symptoms - cp_symptoms

        cp_exclusive_count = len(cp_exclusive & set(self.triggered_symptoms))
        downs_exclusive_count = len(downs_exclusive & set(self.triggered_symptoms))

        if cp_count >= 3 and cp_exclusive_count > downs_exclusive_count:
            self.labels.append("Cerebral Palsy")
            self.reasons.append("Motor and developmental traits suggest cerebral palsy.")
            self.suggestions.append("🛑 Refer to pediatric neurology and physio.")

        elif downs_count >= 3 and downs_exclusive_count > cp_exclusive_count:
            self.labels.append("Down Syndrome")
            self.reasons.append("Distinctive Down Syndrome features present.")
            self.suggestions.append("🧬 Recommend chromosomal testing and therapy.")

        elif cp_count >= 3 and downs_count >= 3:
            self.labels.append("Mixed Motor-Neurodevelopmental Pattern")
            self.reasons.append("Overlap of CP and Down Syndrome indicators. Clinical evaluation required.")
            self.suggestions.append("⚠️ Refer for multidisciplinary review.")

    # Autism vs GDD
    @Rule(SymptomSet())
    def differential_autism_vs_gdd(self):
        autism = {
            'echolalia', 'speech_delay', 'lack_of_social_smile',
            'social_anxiety', 'repetitive_behaviors', 'sensory_issues', 'trouble_following_instructions'
        }
        gdd = {
            'speech_delay', 'learning_difficulty', 'poor_memory', 'delayed_milestones'
        }
        autism_count = len(autism & set(self.triggered_symptoms))
        gdd_count = len(gdd & set(self.triggered_symptoms))

        autism_exclusive = autism - gdd
        gdd_exclusive = gdd - autism

        autism_exclusive_count = len(autism_exclusive & set(self.triggered_symptoms))
        gdd_exclusive_count = len(gdd_exclusive & set(self.triggered_symptoms))

        if autism_count >= 3 and autism_exclusive_count > gdd_exclusive_count:
            self.labels.append("Autism Spectrum Disorder")
            self.reasons.append("Multiple exclusive autism traits detected.")
            self.suggestions.append("🧠 Refer for autism-specific screening and behavioral planning.")

        elif gdd_count >= 3 and gdd_exclusive_count > autism_exclusive_count:
            self.labels.append("Global Developmental Delay")
            self.reasons.append("Speech and cognitive development delays detected.")
            self.suggestions.append("⚠️ Recommend developmental therapy and academic support.")

        elif autism_count >= 3 and gdd_count >= 3:
            self.labels.append("Overlap: ASD + GDD Traits")
            self.reasons.append("Traits align with both ASD and GDD. Complex developmental profile.")
            self.suggestions.append("⚠️ Suggest neuropsych and behavioral evaluation.")

    # --- FALLBACK ---
    @Rule(SymptomSet(
        poor_eye_tracking=False,
        delayed_milestones=False,
        muscle_stiffness=False,
        seizure_episodes=False,
        abnormal_reflexes=False,
        poor_head_control=False,
        lack_of_social_smile=False,
        hyperactivity=False,
        impulsiveness=False,
        speech_delay=False,
        repetitive_behaviors=False,
        learning_difficulty=False,
        poor_memory=False,
        sensory_issues=False,
        trouble_following_instructions=False,
        aggression=False,
        self_harm_behaviors=False,
        social_anxiety=False,
        echolalia=False,
        low_tone=False,
        poor_motor_coordination=False,
        flat_facial_profile=False,
        inattention=False
    ))
    def no_symptoms(self):
        if not self.labels:
            self.labels.append(None)
            self.reasons.append("No significant developmental or behavioral symptoms detected.")
            self.suggestions.append("✅ No critical findings. Monitor and reassess after 3 months.")
